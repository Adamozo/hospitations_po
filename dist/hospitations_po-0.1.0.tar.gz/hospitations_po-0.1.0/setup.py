# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['hospitations_po',
 'hospitations_po.gui',
 'hospitations_po.gui.azure dark',
 'hospitations_po.server']

package_data = \
{'': ['*'],
 'hospitations_po.gui': ['azure dark/assets/*',
                         'azure dark/images/*',
                         'icons/*']}

install_requires = \
['SQLAlchemy>=1.4.31,<2.0.0',
 'fastapi>=0.74.1,<0.75.0',
 'mypy>=0.931,<0.932',
 'psycopg2>=2.9.3,<3.0.0',
 'requests>=2.27.1,<3.0.0',
 'sqlalchemy-stubs>=0.4,<0.5',
 'tk>=0.1.0,<0.2.0',
 'toml>=0.10.2,<0.11.0',
 'types-requests>=2.27.11,<3.0.0',
 'uvicorn>=0.17.5,<0.18.0',
 'yapf>=0.32.0,<0.33.0']

entry_points = \
{'console_scripts': ['start_gui = hospitations_po.gui.main',
                     'start_server = hospitations_po.server.main']}

setup_kwargs = {
    'name': 'hospitations-po',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'Your Name',
    'author_email': 'you@example.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
